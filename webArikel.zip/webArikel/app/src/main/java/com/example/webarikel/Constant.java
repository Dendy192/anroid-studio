package com.example.webarikel;

public class Constant {
    public static final String URL ="http://192.168.43.27/";
    public static final String HOME =URL+"api";
    public static final String CREATE =HOME+"/create";
    public static final String UPDATE =HOME+"/update";


}
