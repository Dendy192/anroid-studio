package com.example.webarikel;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class detailActivity extends AppCompatActivity {
    TextView Djudul, Disi,user;
    Button bEdit, bDelete;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        Bundle bundle = getIntent().getBundleExtra("artikel");
        Artikel Artikel = (com.example.webarikel.Artikel) bundle.getSerializable("artikel");

        Djudul = findViewById(R.id.Djulud);
        Disi = findViewById(R.id.Disi);
        user = findViewById(R.id.user);
        bEdit = findViewById(R.id.bEdit);
        bDelete = findViewById(R.id.bDelete);

        Djudul.setText(Artikel.getJudul());
        Disi.setText(Artikel.getIsi());
        user.setText(Artikel.getUsername());

        bEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), updateActivity.class);
                Bundle bun = new Bundle();
                bun.putSerializable("artikel",Artikel);
                i.putExtra("artikel",bun);
                startActivity(i);
            }
        });

    }
}