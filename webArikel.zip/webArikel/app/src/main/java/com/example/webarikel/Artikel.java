package com.example.webarikel;

import java.io.Serializable;

public class Artikel implements Serializable {
    private Integer id;
    private String username;
    private String judul;
    private String isi;

    public Artikel(Integer id, String username, String judul, String isi) {
        this.id = id;
        this.username = username;
        this.judul = judul;
        this.isi = isi;
    }
    public Artikel(){

    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getJudul() {
        return judul;
    }

    public void setJudul(String judul) {
        this.judul = judul;
    }

    public String getIsi() {
        return isi;
    }

    public void setIsi(String isi) {
        this.isi = isi;
    }
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}
