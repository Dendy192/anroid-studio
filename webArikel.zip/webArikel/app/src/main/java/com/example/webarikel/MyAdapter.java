package com.example.webarikel;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {

    private ArrayList<Artikel> artikel;
    Context mContext;

    public MyAdapter( Context mContext, ArrayList<Artikel> artikel) {

        this.mContext = mContext;
        this.artikel = artikel;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(mContext).inflate(R.layout.detail_artikel, parent, false);

        MyViewHolder myViewHolder = new MyViewHolder(v);

        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        final Artikel artikels = artikel.get(position);

        holder.judul.setText(artikels.getJudul());
                holder.isi.setText(artikels.getIsi());
                holder.user.setText(artikels.getUsername());
                holder.ReB.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(mContext, detailActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putSerializable("artikel", artikels);
                        intent.putExtra("artikel", bundle);
                        mContext.startActivity(intent);
                    }
                });
    }

    @Override
    public int getItemCount() {

        return artikel.size();
    }

    static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView judul;
        TextView isi;
        TextView user;
        Button ReB;




        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            judul = itemView.findViewById(R.id.judul);
            isi = itemView.findViewById(R.id.isi);
            user = itemView.findViewById(R.id.user);
            ReB = itemView.findViewById(R.id.ReB);

        }
    }

}
