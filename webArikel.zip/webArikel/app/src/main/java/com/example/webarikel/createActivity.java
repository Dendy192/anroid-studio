package com.example.webarikel;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;



public class createActivity extends AppCompatActivity {
    private EditText username, judulArtikel, isiArtikel;
    Button postBtn;
    String user,judul,isi;
    private SharedPreferences preferences;
    private ProgressDialog progressDialog;
    ArrayList<Artikel> artikels;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);
        username = findViewById(R.id.username);
        judulArtikel = findViewById(R.id.judulArtikel);
        isiArtikel = findViewById(R.id.isiArtikel);
        postBtn = findViewById(R.id.postBtn);
        progressDialog = new ProgressDialog(this);

        postBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                 user = username.getText().toString();
                 judul = judulArtikel.getText().toString();
                 isi = isiArtikel.getText().toString();


                if(TextUtils.isEmpty(user)){
                    Toast.makeText(createActivity.this, "Please fill username", Toast.LENGTH_SHORT).show();
                }
                else if(TextUtils.isEmpty(judul)){
                    Toast.makeText(createActivity.this, "Please fill judul", Toast.LENGTH_SHORT).show();
                }
                else if(TextUtils.isEmpty(isi)){
                    Toast.makeText(createActivity.this, "Please fill isi", Toast.LENGTH_SHORT).show();
                }
                else{


                    register();
                    progressDialog.setMessage("Posting......");
                    progressDialog.show();

                }


            }
        });
    }

    private void register(){
        StringRequest request = new StringRequest(Request.Method.POST,Constant.CREATE,response -> {

            try {
                JSONObject object = new JSONObject(response);
                if (object.getBoolean("success")){
                    JSONObject postObject = object.getJSONObject("post");
                    JSONObject userObject = postObject.getJSONObject("user");


                    Artikel ar = new Artikel();
                    ar.setId(postObject.getInt("id"));
                    ar.setJudul(postObject.getString("judul"));
                    ar.setIsi(postObject.getString("isi"));
                    ar.setUsername(postObject.getString("username"));


                    artikels.add(0,ar);
                    Toast.makeText(this, "Posted", Toast.LENGTH_SHORT).show();
                    finish();


                }
            } catch (JSONException e) {
                e.printStackTrace();
            }


        },error -> {
            error.printStackTrace();

        }){

            // add token to header


            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                String token = preferences.getString("token","");
                HashMap<String,String> map = new HashMap<>();
                map.put("Authorization","Bearer "+token);
                return map;
            }




        };

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(request);
        Intent i = new Intent(createActivity.this, MainActivity.class);
        startActivity(i);

    }




}