package com.example.webarikel;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;



public class updateActivity extends AppCompatActivity {
    EditText Eusername, EjudulArtikel, EisiArtikel;
    Button EpostBtn;
    String key = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getIntent().getBundleExtra("artikel");
        Artikel Artikel = (com.example.webarikel.Artikel) bundle.getSerializable("artikel");
        setContentView(R.layout.activity_update);
        Eusername = findViewById(R.id.Eusername);
        EjudulArtikel = findViewById(R.id.EjudulArtikel);
        EisiArtikel = findViewById(R.id.EisiArtikel);
        EpostBtn = findViewById(R.id.EpostBtn);

        Eusername.setText(Artikel.getUsername());
        EjudulArtikel.setText(Artikel.getJudul());
        EisiArtikel.setText(Artikel.getIsi());

        String ej = EjudulArtikel.getText().toString();
        String eu = Eusername.getText().toString();


        EpostBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = Eusername.getText().toString();
                String judul = EjudulArtikel.getText().toString();
                String isi = EisiArtikel.getText().toString();

                if(TextUtils.isEmpty(username)){
                    Toast.makeText(updateActivity.this, "username must be filled", Toast.LENGTH_SHORT).show();
                }
                else if(TextUtils.isEmpty(judul)){
                    Toast.makeText(updateActivity.this, "judul must be filled", Toast.LENGTH_SHORT).show();
                }
                else if(TextUtils.isEmpty(isi)){
                    Toast.makeText(updateActivity.this, "isi must be filled", Toast.LENGTH_SHORT).show();
                }
                else{


                }
            }
        });

    }
}